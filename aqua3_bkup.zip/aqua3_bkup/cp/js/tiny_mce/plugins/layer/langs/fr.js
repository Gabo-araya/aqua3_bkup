// FR lang variables
// Modified by shadow walker, last updated 2007-03-16

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Ins&eacute;rer un nouveau calque',
forward_desc : 'Avancer',
backward_desc : 'Reculer',
absolute_desc : 'Passer en positionnement absolu',
content : 'Nouveau calque...'
});
