// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
paste_text_desc : 'Coller comme du texte',
paste_text_title : 'Faites CTRL+V pour coller le texte dans la fen&ecirc;tre.',
paste_text_linebreaks : 'Conserver les retours &agrave; la ligne',
paste_word_desc : 'Coller depuis Word',
paste_word_title : 'Faites CTRL+V pour coller le texte dans la fen&ecirc;tre.',
selectall_desc : 'S&eacute;lectionner tout'
});
