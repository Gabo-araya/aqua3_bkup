// NL lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Plakken als platte tekst',
paste_text_title : 'Gebruik CTRL+V op uw toetsenbord om de tekst in het venster te plakken.',
paste_text_linebreaks : 'Behoud regeleinden',
paste_word_desc : 'Plakken uit Word',
paste_word_title : 'Gebruik CTRL+V op uw toetsenbord om de tekst in het venster te plakken.',
selectall_desc : 'Alles selecteren'
});
