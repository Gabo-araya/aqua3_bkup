// RU lang variables UTF-8

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Это шаблон для всплывающего окна',
template_desc : 'Это шаблон для кнопки'
});
