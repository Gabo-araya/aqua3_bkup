// RU lang variables

tinyMCE.addToLang('',{
preview_desc : 'Предварительный просмотр'
});
