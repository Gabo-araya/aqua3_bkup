// RU lang variables

tinyMCE.addToLang('emotions',{
title : 'Вставить смайлик',
desc : 'Смайлики',
cool : 'Круто',
cry : 'Плач',
embarassed : 'Смущенный',
foot_in_mouth : 'Косноязычный',
frown : 'Нахмуренный',
innocent : 'Святой',
kiss : 'Поцелуй',
laughing : 'Смех',
money_mouth : 'Дельный',
sealed : 'Заклеенный',
smile : 'Улыбка',
surprised : 'Сюрприз',
tongue_out : 'Высунутый язык',
undecided : 'Нерешительный',
wink : 'Подмигнуть',
yell : 'Вопль'
});
