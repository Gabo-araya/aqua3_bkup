// HU lang variables

tinyMCE.addToLang('emotions',{
title : 'Hangulatjel beszúrása',
desc : 'Hangulatjelek',
cool : 'Király',
cry : 'Sírás',
embarassed : 'Zavart',
foot_in_mouth : 'Foot in mouth',
frown : 'Homlokráncolás',
innocent : 'Ártatlan',
kiss : 'Csók',
laughing : 'Nevetés',
money_mouth : 'Pénzéhes',
sealed : 'Elnémult',
smile : 'Mosolygás',
surprised : 'Meglepett',
tongue_out : 'Tongue out',
undecided : 'Határozatlan',
wink : 'Kacsintás',
yell : 'Sikoltás'
});
