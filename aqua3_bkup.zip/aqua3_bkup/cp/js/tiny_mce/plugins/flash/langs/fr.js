// FR lang variables
// Modified by keyko-web.net, last updated 2007-03-08, based on the work of Motte

tinyMCE.addToLang('flash',{
title : 'Gestionnaire d\'animation Flash',
desc : 'Ins&eacute;rer une animation Flash',
file : 'Fichier Flash (.swf)',
size : 'Taille',
list : 'Liste des fichiers Flash',
props : 'Propri&eacute;t&eacute;s Flash',
general : 'G&eacute;n&eacute;ral'
});
