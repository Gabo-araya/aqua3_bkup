// HU lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Általános',
tab_appearance : 'Megjelenés',
tab_advanced : 'Haladó',
general : 'Általános',
title : 'Cím',
preview : 'Elõnézet',
constrain_proportions : 'Arányok kényszerítése',
langdir : 'Szöveg pozíció',
langcode : 'Szöveg kód',
long_desc : 'Hosszú leírás link',
style : 'Stílus',
classes : 'Osztályok',
ltr : 'Balról jobbra',
rtl : 'Jobbról balra',
id : 'Azonosító',
image_map : 'Kép térkép',
swap_image : 'Kép váltás',
alt_image : 'Másik kép',
mouseover : 'egér rámutatásra',
mouseout : 'egér elmozdítására',
misc : 'Egyéb',
example_img : 'Elõnézeti&nbsp;kép&nbsp;megjelenése',
missing_alt : 'Are you sure you want to continue without including an Image Description? Without  it the image may not be accessible to some users with disabilities, or to those using a text browser, or browsing the Web with images turned off.'
});
