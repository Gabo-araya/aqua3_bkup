// DE lang variables

tinyMCE.addToLang('spellchecker',{
	desc : 'RechtschreibprÃ¼fung ein-/ausschalten',
	menu : 'Einstellungen der RechtschreibprÃ¼fung',
	ignore_word : 'Wort ingorieren',
	ignore_words : 'Alle ignorieren',
	langs : 'Sprachen',
	wait : 'Bitte warten...',
	swait : 'RechtschreibprÃ¼fung, bitte warten...',
	sug : 'VorschlÃ¤ge',
	no_sug : 'Keine VorschlÃ¤ge',
	no_mpell : 'Keinen Rechtschreibfehler gefunden.'
});
