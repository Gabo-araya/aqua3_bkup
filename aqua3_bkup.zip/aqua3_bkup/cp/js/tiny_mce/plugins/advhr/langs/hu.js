// HU lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vízszintes vonal beillesztése / szerkesztése',
insert_advhr_width : 'Hosszúság',
insert_advhr_size : 'Szélesség',
insert_advhr_noshade : 'Nincs árnyék'
});
