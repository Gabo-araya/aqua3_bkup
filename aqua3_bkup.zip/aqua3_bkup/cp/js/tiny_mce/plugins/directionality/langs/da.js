// DK lang variables - Transl.:Jan Moelgaard, Bo Frederiksen, John Dalsgaard - Corr.:

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Retning - venstre mod h&oslash;jre',
directionality_rtl_desc : 'Retning - h&oslash;jre mod venstre'
});
