// RU lang variables

tinyMCE.addToLang('',{
print_desc : 'Распечатать'
});
