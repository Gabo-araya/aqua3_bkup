// DK lang variables - Transl.:Jan Moelgaard, Bo Frederiksen, John Dalsgaard - Corr.:

tinyMCE.addToLang('',{
autosave_unload_msg : 'De &aelig;ndringer, du har lavet, vil g&aring; tabt, hvis du lukker denne side.'
});
