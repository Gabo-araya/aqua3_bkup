// RU lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Изменения не будут потеряны если Вы уйдёте с этой страницы.'
});
