// RU lang variables

tinyMCE.addToLang('',{
save_desc : 'Ð¡Ð¾Ñ…Ñ€Ð°Ð½Ð¸Ñ‚ÑŒ'
});
